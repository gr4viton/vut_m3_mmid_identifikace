function [Fz] = GET_tf(TSTEP, K, theta, M, N)
%GET_TF returns transfer function from created input
global z

z = tf('z',TSTEP);
numerator = 0;
denominator = 1;

% theta(b0, b1, b2,.., bm, a0, a1, a2,..,an)

for m = 0 : (M)
    numerator = numerator + theta(1+m) * z^-m;
end
numerator = numerator * z^-1; % ze vzorkov�n�
o_off = M+1;
for n = 0 : (N-1)
    denominator = denominator + theta(o_off+1+n) * z^-n;
end

Fz = K * numerator / denominator;

end

